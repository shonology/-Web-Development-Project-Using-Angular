function log(message){
    console.log(message);
}

var message = 'Hello amigos';
log(message);